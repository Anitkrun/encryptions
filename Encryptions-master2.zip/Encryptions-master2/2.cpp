
#include<stdio.h>
#include<iostream>
#include"Encryptions.h"
#include"encrypt-sync.h"

using namespace std;

int main(){

std:string key ("Thats my Kung Fu");
//AES instance(key);
SymAlg * instance = new AES(key);
std::string data;
std::string IV("0000000000000000");
std::string ciphertext;
std::string plaintext("1234567890Thatsmy KungFu");
data = CFB(instance, IV).encrypt(plaintext);
//ciphertext = instance->encrypt(plaintext);
std::cout<<data<<endl;
delete(instance);
return 0;
}

 
            
            
