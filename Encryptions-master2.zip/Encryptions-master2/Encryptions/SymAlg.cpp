#include "SymAlg.h"

SymAlg::SymAlg() 
    : keyset(false)
{}

SymAlg::~SymAlg(){}
